import React  from 'react';
import './layout.css';

const Wapper= () =>{
        return (  

        <div class="wrapper">
    
        <nav id="sidebar">
            <div class="sidebar-header">
                <h5>Bootstrap</h5>
            </div>
    
            <ul class="list-unstyled components">
               
                <li class="active">
                    <a href="#homeSubmenu"  >Home</a>
                    
                </li>
                <li>
                    <a href="#">About</a>
                </li>
                {/* <li>
                    <a href="#pageSubmenu" >Pages</a>
                    
                </li>
                <li>
                    <a href="#">Portfolio</a>
                </li>
                <li>
                    <a href="#">Contact</a>
                </li> */}
            </ul>
    
        </nav>
       
        
        
     
      
    </div>
      );
    }




    
 
export default Wapper;