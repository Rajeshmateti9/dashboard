import React from 'react';
import NumContent from'./NumContent';
import './layout.css';

const TextBox = () =>{
    
        return ( 
           <div> 
                <div class="textcon ">
            <h4>Bots</h4>
             <div class="row">

            <div class="box1  col-md-3 col-sm-3">
              <div class="textbox">
                  <NumContent />
           
               </div>
             </div>

             <div class="box1 col-md-3 col-sm-3">
              <div class="textbox">
               
                <NumContent />
              
               
               </div>
             </div>

             <div class="box1  col-md-3 col-sm-3">
              <div class="textbox">
              
               <NumContent />
              
              
               </div>
             </div>
             <div class="box1  col-md-3 col-sm-3">
             <div class="textbox">
            
               <NumContent />
               
             
               </div>
             </div>
          </div>
            
              
             </div>
             
             <div class="showmore">
               <button class="btn btn-primary">Show More</button>
             </div>
           </div>
         );
    
}
 
export default TextBox;