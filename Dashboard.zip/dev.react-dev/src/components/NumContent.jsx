import React, { Component } from 'react';

import './layout.css';

const NumContent = () => {
     
        return (
            <div>
                    <div class="text">
                <h5>lorem</h5><hr class="hreeee"/>
                <div class="row">
               <div class="numbers col" >
                    <p>num1</p>
                    <p>num2</p>
                    <p>num3</p>
               </div>
               <div class="numbers1 col" >
                    <p>100</p>
                    <p>150</p>
                    <p>200</p>
               </div>
               </div>
               <div class="view">
               <button class="btn btnview btn-sm">view</button>
             </div>
              
               </div>
            </div>
         );
    
}
 
export default NumContent;