import React from 'react';
import './layout.css';
import Content from './Content';


const NavBar = () =>{
        return ( 
            <div id="content">
    
            <nav class="navbar navbar-expand-lg ">
                <div class="container-fluid">
    
                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span></span>
                       
                    </button>
                </div>
                <div style={{float:"right"}}>
                          <ul class="dash">
                            <li>
                              XXXXXXXXXXXXXX
                            </li>
                          </ul>
                        </div> 
            </nav>
            
            <Content />
            
        </div>
        
         );
}
 
export default NavBar;