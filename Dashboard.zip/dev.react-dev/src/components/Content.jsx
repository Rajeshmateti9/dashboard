import React from 'react';
import './layout.css';
import TextBox from './TextBox';


const Content = () => {
        return ( 
                   
          <div class="textcon">
          <div class="row">
            <div class=" col-sm-6">
              <div class="textbox">
                <div class="text">
                <h5>Heading</h5>
               <p>A all yjrt hhd dxyjy kjhwetn jhiugtgn</p>
               < button class="btn btn-primary">+create</button>
               </div>
               </div>
             </div>
             <div class="col-sm-6">
             <div class="textbox">
             <div class="text">
                <h5>Heading</h5>
                <p>A all yjrt hhd dxyjy kjhwetn jhiugtgn</p>
               < button class="btn btn-primary">+create</button>
               </div>
               </div>
             </div>
          </div>
          <div class="textcon">
            <div class="textbox22">
              <div>
              <span>Heading</span>
              
              <button class="btn2"><img src="images1.png"></img> </button>
              <button class="btn3"><img src="images2.png"></img> </button>
              </div>
              <hr/>
               
               <hr />
            
              </div>
             </div>
             <div class="textcon">
            <div class="textbox22">
              
              <div>
              
              <button class="btn2"><b>btn2</b></button>
              <button class="btn3"><b>btn3</b></button>
              </div>
              {/* <p>heading</p> */}
              <hr class="horref1"/></div>
            
             </div>
             
             <TextBox />

             <hr class="hree3"/>

             <div class="row">
            <div class=" col-md-4">
              <div class="textbox">
                <div class="text">
                <h5>lorem</h5>
               <p>hiiiifjujirudsgu</p>
              
               </div>
               </div>
             </div>
             <div class="col-md-4">
             <div class="textbox">
             <div class="text">
                <h5>lorem</h5>
               <p>hiiiifjujirudsgu</p>
              
               </div>
               </div>
             </div>
          </div>

       </div>
       
   
        
         );
    
}


export default Content;