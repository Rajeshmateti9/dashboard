import React from 'react';

import './App.css';
import Wapper from './components/Wapper';
import NavBar from './components/NavBar';
import Content from './components/Content';

function App() {
  return (
    <div>
    <Wapper />
    <NavBar/>
  
    
    </div>
  );
}

export default App;
